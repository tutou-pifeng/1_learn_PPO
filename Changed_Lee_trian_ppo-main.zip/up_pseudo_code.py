# prompt_dataset
# activate_model

for batch_prompt in prompt_dataset:
    # action LLM 的输出
    batch_response = active_model.generate(batch_prompt)
    # reward LLM 的输出
    batch_scores = reward_model(batch_data)
    
    # batch_all_probs中，存储，比如超级马里奥中，up\left\right的分别的概率，如：[0.2，0.7，0.1]
    # batch_probs中，存储，动作空间中，选择的那个动作的概率，比如是，up,则有，0.2.
    batch_all_probs,batch_probs,batch_all_values = active_model.forward_pass(batch_data)
    ref_all_probs,ref_probs,ref_all_values = ref_model.forward_pass(batch_data)
    
    kls = compute_KL(batch_all_probs,ref_all_probs)
    rewards = compute_rewards(batch_scores,kls)
    advantages = compute_advantages(batch_all_values,rewards)
    returns = advantages+batch_all_values    

    for i in range(epoch):
        activate_all_probs,active_probs,active_all_values = active_model.forward_pass(batch_data)
        
        loss_state_value = torch.mean((retuens-active_all_values)**2)
        ratio = active_probs/batch_probs
        loss_ppo = torch,mean(-advantages*ratio)
        loss=loss_ppo + value_loss_rate*loss_state_value
        loss.backward()
        optimizer.step()
        aptimizer.zero_grad() 









